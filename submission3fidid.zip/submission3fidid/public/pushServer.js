const webpush = require('web-push');

const vapidKeys = {
    "publicKey": "BNsnohMtCt4OGlLhdWpkkeWlB4SqtMEt0ZHnVy4UXARUV9q8JMLHwpiIn--1khYtcv2u6ySBe-Cmjr3JaFTZNgI",
    "privateKey": "8dOGWfQvxGXWi4o84h-WAO4gqPKDCyDrVVI98e18mNM"
};

webpush.setGCMAPIKey('AAAAUXJJn7I:APA91bEnR4ACvPtnhfgDExv7X8m73w35Bt2l3C6ml4Aenz1oPBRy2wjTKkUyNb3ySXhoI8w87pvNZFN4PDAA2Yb8DEmP4VA9ZTzLU5egbQPWyasQv6MqlKE2UYVcfPeWDm79wXLMvGSP')
webpush.setVapidDetails(
    'mailto:example@yourdomain.org',
    vapidKeys.publicKey,
    vapidKeys.privateKey
)

const pushSubscribtion = {
    endpoint: 'https://fcm.googleapis.com/fcm/send/crTh8SA--0s:APA91bF6C9UBwIY_mlCp4XZkZgnbDS29vuczGwaIHoPgHEoadBulUTcAgPdNlVz-SRJApEiSGo3SgkB0UCjpFgZhHXCMY7BiZEAN2_YVy8jfSZ65_CCrNznzVleDv3aRU61CXHWjPRw',
    keys: {
        auth: 'VC1uKSsAA33rUSVuNlU/dA==',
        p256dh: 'BKnrwZHgKUJcUzqwZk2pcs8Md6+sjrIC494A3C/qjA0ENi2kV15cW0kq09BZSxRxMsbg9jpz8tIliHpMFrta6yQ='
    }
}

webpush.sendNotification(pushSubscribtion, 'Payload body From Server')