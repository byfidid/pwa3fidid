importScripts(
  "https://storage.googleapis.com/workbox-cdn/releases/4.3.1/workbox-sw.js"
);

if (workbox) {
  console.log(`Workbox berhasil dimuat`);
  workbox.precaching.precacheAndRoute([{
      url: "/",
      revision: '2'
    },
    {
      url: "/manifest.json",
      revision: '2'
    },
    {
      url: "/index.html",
      revision: '2'
    },
    {
      url: "/src/components/nav.html",
      revision: '2'
    },
    {
      url: "/src/pages/home.html",
      revision: '2'
    },
    {
      url: "/src/pages/teams.html",
      revision: '2'
    },
    {
      url: "/src/pages/bookmark.html",
      revision: '2'
    },
    {
      url: "/src/images/icon192.png",
      revision: '2'
    },
    {
      url: "/src/images/icon512.png",
      revision: '2'
    },
    {
      url: "/src/images/wallpaper.jpg",
      revision: '2'
    },
    {
      url: "/src/images/wallpaper2.jpg",
      revision: '2'
    },
    {
      url: "/src/images/wallpaper3.jpg",
      revision: '2'
    },
    {
      url: "/assets/js/idb.js",
      revision: '2'
    },
    {
      url: "/assets/css/main.css",
      revision: '2'
    },
    {
      url: "/assets/css/materialize.min.css",
      revision: '2'
    },
    {
      url: "/assets/js/main.js",
      revision: '2'
    },
    {
      url: "/assets/js/materialize.min.js",
      revision: '2'
    },
    {
      url: "/assets/js/api.js",
      revision: '2'
    },
    {
      url: "/assets/js/nav.js",
      revision: '2'
    },
    {
      url: "/assets/js/page.js",
      revision: '2'
    },
    {
      url: "/assets/js/database.js",
      revision: '2'
    },
    {
      url: "/assets/js/listener.js",
      revision: '2'
    },
    {
      url: "/assets/js/pwa.js",
      revision: '2'
    },
  ]);

  workbox.routing.registerRoute(
    /.*(?:googleapis|gstatic)\.com/,
    workbox.strategies.staleWhileRevalidate({
      cacheName: 'google-fonts-stylesheets',
    })
  );

  workbox.routing.registerRoute(
    /.*(?:png|gif|jpg|jpeg|svg|ico)$/,
    workbox.strategies.cacheFirst({
      cacheName: 'images-cache',
      plugins: [
        new workbox.cacheableResponse.Plugin({
          statuses: [0, 200]
        }),
        new workbox.expiration.Plugin({
          maxEntries: 100,
          maxAgeSeconds: 30 * 24 * 60 * 60,
        }),
      ]
    })
  );

  workbox.routing.registerRoute(
    new RegExp('https://api.football-data.org/'),
    workbox.strategies.staleWhileRevalidate()
  )

  workbox.routing.registerRoute(
    /\.(?:js|css)$/,
    new workbox.strategies.StaleWhileRevalidate({
      cacheName: 'static-resources',
    })
  );

  workbox.routing.registerRoute(
    new RegExp('/pages/'),
    workbox.strategies.staleWhileRevalidate({
      cacheName: 'pages'
    })
  );
} else {
  console.log(`Workbox gagal dimuat`);
}

self.addEventListener("push", (event) => {
  let body;

  event.data ? (body = event.data.text()) : (body = "No Payload");
  const options = {
    body: body,
    icon: "/src/images/icon192.png",
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1,
    },
  };
  event.waitUntil(
    self.registration.showNotification("Push Notification", options)
  );
});