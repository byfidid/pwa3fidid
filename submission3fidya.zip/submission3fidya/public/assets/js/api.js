const base_url = "https://api.football-data.org";
const api_token = "7d78ab88e5d2499583d139311eb09ada";

let status = (res) => {
    if (res.status !== 200) {
        console.log(`Error : ${res.status}`);
        return Promise.reject(new Error(res.statusText()));
    } else {
        return Promise.resolve(res);
    }
};

const getStandings = (leagueID) => {
    if ("caches" in window) {
        caches
            .match(`${base_url}/v2/competitions/${leagueID}/standings`)
            .then((res) => {
                if (res) {
                    res
                        .json()
                        .then((data) => {
                            let standingsHTML = "";
                            data = data.standings[0].table;

                            data.forEach((dataTeam) => {
                                let urlTeamImage = dataTeam.team.crestUrl;
                                urlTeamImage = urlTeamImage.replace(/^http:\/\//i, "https://");
                                standingsHTML += `
                                <tr>
                                    <td class="center-align">${dataTeam.position}</td>
                                    <td class="center-align"><img src="${urlTeamImage}" alt="${dataTeam.team.name}" class="responsive-img" width="30"></td>
                                    <td>${dataTeam.team.name}</td>
                                    <td class="center-align">${dataTeam.playedGames}</td>
                                    <td class="center-align">${dataTeam.won}</td>
                                    <td class="center-align">${dataTeam.draw}</td>
                                    <td class="center-align">${dataTeam.lost}</td>
                                    <td class="center-align">${dataTeam.goalsFor}</td>
                                    <td class="center-align">${dataTeam.goalsAgainst}</td>
                                    <td class="center-align">${dataTeam.goalDifference}</td>
                                    <td class="center-align">${dataTeam.points}</td>
                                </tr>`;
                            });
                            document.getElementById("progress").style.display = "none";
                            document.getElementById("standings").innerHTML = standingsHTML;
                        })
                        .catch((err) => console.log(err));
                }
            });
    }

    fetch(`${base_url}/v2/competitions/${leagueID}/standings`, {
            headers: {
                "X-Auth-Token": api_token,
            },
        })
        .then(status)
        .then((res) => res.json())
        .then((data) => {
            let standingsHTML = "";
            data = data.standings[0].table;

            data.forEach((dataTeam) => {
                let urlTeamImage = dataTeam.team.crestUrl;
                urlTeamImage = urlTeamImage.replace(/^http:\/\//i, "https://");
                standingsHTML += `
                <tr>
                    <td class="center-align">${dataTeam.position}</td>
                    <td class="center-align"><img src="${urlTeamImage}" alt="${dataTeam.team.name}" class="responsive-img" width="30"></td>
                    <td>${dataTeam.team.name}</td>
                    <td class="center-align">${dataTeam.playedGames}</td>
                    <td class="center-align">${dataTeam.won}</td>
                    <td class="center-align">${dataTeam.draw}</td>
                    <td class="center-align">${dataTeam.lost}</td>
                    <td class="center-align">${dataTeam.goalsFor}</td>
                    <td class="center-align">${dataTeam.goalsAgainst}</td>
                    <td class="center-align">${dataTeam.goalDifference}</td>
                    <td class="center-align">${dataTeam.points}</td>
                </tr>
            `;
            });
            document.getElementById("progress").style.display = "none";
            document.getElementById("standings").innerHTML = standingsHTML;
        })
        .catch((err) => console.log(err));
};

const getTeams = (leagueID) => {
    if ("caches" in window) {
        caches
            .match(`${base_url}/v2/competitions/${leagueID}/teams`)
            .then((res) => {
                if (res) {
                    res.json().then((data) => {
                        let teamsHTML = "";
                        data = data.teams;
                        data.forEach((team) => {
                            let urlTeamImage = team.crestUrl;
                            urlTeamImage = urlTeamImage.replace(/^http:\/\//i, "https://");
                            teamsHTML += `
                                <div class="col s12">
                                    <div class="card">
                                    <div class="card-content row valign-wrapper">
                                        <div class="col s4" class="logo-team">
                                            <img src="${urlTeamImage}" alt="${team.name}" class="responsive-img center-align" width="50%">
                                        </div>
                                        <div class="col s8 information-team">
                                        <span class="badge-blue"><strong>${team.name}</strong></span>
                                        <span>${team.venue}</span>
                                        </div>
                                    </div>
                                    <div class="card-action right-align">
                                        <a href="${team.website}" target="_blank" class="website-action">Link Web</a>
                                        <button onclick="addBookmarkTeam(${team.id},'${urlTeamImage}','${team.name}','${team.venue}','${team.website}')
                                        "class="waves-effect waves-light btn orange darken-4">ADD</button>
                                    </div>
                                    </div>
                                </>
                                `;
                        });
                        document.getElementById("progress").style.display = "none";
                        document.getElementById("teams").innerHTML = teamsHTML;
                    });
                }
            });
    }
    fetch(`${base_url}/v2/competitions/${leagueID}/teams`, {
            headers: {
                "X-Auth-Token": api_token,
            },
        })
        .then(status)
        .then((res) => res.json())
        .then((data) => {
            let teamsHTML = "";
            data = data.teams;
            data.forEach((team) => {
                let urlTeamImage = team.crestUrl;
                let nameTeam = team.name.toLowerCase()
                urlTeamImage = urlTeamImage.replace(/^http:\/\//i, "https://");
                teamsHTML += `
            <div class="col s12" >
                <div class="card">
                <div class="card-content row valign-wrapper">
                    <div class="col s4" class="logo-team">
                        <img src="${urlTeamImage}" alt="${team.name}" class="responsive-img center-align" width="50%" >
                    </div>
                    <div class="col s8 information-team">
                    <span class="badge-blue"><h4>${team.name}</h4></span>
                    <span>${team.venue}</span>
                    </div>
                </div>
                <div class="card-action right-align">
                    <a href="${team.website}" target="_blank" class="website-action pink darken-3">LINK</a>
                    <button onclick="addBookmarkTeam(${team.id},'${urlTeamImage}','${team.name}','${team.venue}','${team.website}')" 
                    class="waves-effect waves-light btn pink darken-3">Add Bookmark</button>
                </div>
                </div>
            </div>
            `;
            });
            document.getElementById("progress").style.display = "none";
            document.getElementById("teams").innerHTML = teamsHTML;
        })
        .catch((err) => console.log(err));
};

export default {
    getStandings,
    getTeams,
};