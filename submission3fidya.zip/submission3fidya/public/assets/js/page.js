import api from './api.js'
import listener from './listener.js'

const loadPage = (path = 'home') => {
    let xhr = new XMLHttpRequest()
    xhr.onreadystatechange = () => {
        if (xhr.readyState == 4) {
            let element = document.querySelector('#body-content')
            if (xhr.status === 200) {
                element.innerHTML = xhr.responseText
                if (path === 'home') {
                    api.getStandings(2014)
                }
                if (path === 'bookmark') {
                    listener.getAllTeam()
                    window.deleteBookmarkTeam = listener.deleteBookmarkTeam
                }
                if (path === 'teams') {
                    api.getTeams(2014)
                    window.addBookmarkTeam = listener.addBookmarkTeam
                }

            } else if (xhr.status == 404) {
                element.innerHTML = "<h3>Halaman tidak ditemukan</h3>"
            } else {
                element.innerHTML = "<h3>Maaf halaman tidak dapat di akses</h3>"
            }
        }
    }
    xhr.open('GET', `/src/pages/${path}.html`, true)
    xhr.send()
}

export default loadPage