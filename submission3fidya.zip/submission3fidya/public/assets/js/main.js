import loadNav from './nav.js'
import loadPage from './page.js'
import pwa from './pwa.js'

let path = window.location.hash.substr(1)
path ? path = path : path = 'home'

pwa.registration()
pwa.notification()

document.addEventListener('DOMContentLoaded', () => {
    loadNav()
    loadPage(path)
})