import database from './database.js'

const getAllTeam = () => {
    database.getTeam()
        .then(data => {
            let teamsHTML = ''
            data.forEach(team => {
                teamsHTML +=
                    `
                <div class="col s12">
                    <div class="card">
                    <div class="card-content row valign-wrapper">
                        <div class="col s4" class="logo-team">
                            <img src="${team.logo}" alt="${team.name}" class="responsive-img center-align" width="50%" >
                        </div>
                        <div class="col s8 information-team">
                        <span class="badge-blue"><strong>${team.name}</strong></span>
                        <span>${team.venue}</span>
                        </div>
                    </div>
                    <div class="card-action center-align">
                        <button onclick="deleteBookmarkTeam(${team.id},'${team.name}')
                        "class="waves-effect waves-light btn pink darken-3">Delete</button>
                    </div>
                    </div>
                </div>
                `
            })
            document.getElementById('progress').style.display = 'none'
            document.getElementById('bookmarkTeams').innerHTML = teamsHTML
        })
}

const pushNotification = msg => {
    const title = 'Notifikasi';
    const options = {
        body: msg,
        icon: '/icon.png'
    };
    if (Notification.permission === 'granted') {
        navigator.serviceWorker.ready.then(regis => {
            regis.showNotification(title, options);
        });
    }
}

const addBookmarkTeam = (id, logo, name, venue, website) => {
    database.addTeam({
        id,
        logo,
        name,
        venue,
        website
    })
    M.toast({
        html: `Berhasil Menambahkan Bookmark ${name}`,
    });
    pushNotification(`Berhasil Menambahkan Bookmark ${name}`)
}

const deleteBookmarkTeam = (id, name) => {
    let imSure = confirm(`Ingin menghapus ${name} dari Bookmark ?`)
    if (imSure) {
        database.deleteTeam(id)
        getAllTeam()
        M.toast({
            html: `Berhasil Menghapus ${name}`,
        })
        pushNotification(`Berhasil Menghapus ${name}`)
    }

}

export default {
    addBookmarkTeam,
    getAllTeam,
    deleteBookmarkTeam
}