const webpush = require('web-push');

const vapidKeys = {
    "publicKey": "BOMkBklL6uTGYyNkVo_BF0PjqpmmJ3ubkaZjX_SW0BUskXu2QJ1bb4VidVxZXPm7eTnI_PPvLRBcw9kPWzpguOw",
    "privateKey": "A8HeDxiWfc_xRleccT0olgiMbikZxsEDoV0XrNu4ATQ"
};

webpush.setGCMAPIKey('AAAAUXJJn7I:APA91bEnR4ACvPtnhfgDExv7X8m73w35Bt2l3C6ml4Aenz1oPBRy2wjTKkUyNb3ySXhoI8w87pvNZFN4PDAA2Yb8DEmP4VA9ZTzLU5egbQPWyasQv6MqlKE2UYVcfPeWDm79wXLMvGSP')
webpush.setVapidDetails(
    'mailto:example@yourdomain.org',
    vapidKeys.publicKey,
    vapidKeys.privateKey
)

const pushSubscribtion = {
    endpoint: 'https://fcm.googleapis.com/fcm/send/dNtmIkCVbdU:APA91bHAoNgj_0iw9n7bVFU8bKHfbqEteWi0WAEkaOym6fh0bQcPtpYp3Y-lC1S117OnWU56Ih4NODqQpXsBNYYNbqTxOJAQs-drIGk2Rfwy-ao8xbHv1aQDU0m5IlAlzx174xtXOddt',
    keys: {
        auth: 'qEjC/pEkvaHb8b8VSqBlgA==',
        p256dh: 'BCDlyYRqIffhRIxHxJMM9C83L9OTV5uwjrswsBpot+9e89xLG3GOlYSdBu0Y+RyQODZd+frxEhWXfx1WsbMaNMo='
    }
}

webpush.sendNotification(pushSubscribtion, 'Payload body From Server')